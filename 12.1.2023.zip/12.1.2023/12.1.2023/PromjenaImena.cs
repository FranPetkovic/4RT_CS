﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._1._2023
{
    public class PromjenaImena
    {
        public delegate void PromjenaImenaDel(string ime);
        public event PromjenaImenaDel promijeniIme;

        public void promjena(string ime)
        {
            if(promijeniIme != null)
            {
                this.promijeniIme(ime);
            }
        }
    }
}
