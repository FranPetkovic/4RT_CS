﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12._1._2023
{
    public partial class Form1 : Form
    {
        PromjenaImena obj = new PromjenaImena();

        public Form1()
        {
            InitializeComponent();
            obj.promijeniIme += this.PromijeniIme;
        }

        private void PromijeniIme(string ime)
        {
            this.Text = ime;
        }

        private void button_Promijeni_Click(object sender, EventArgs e)
        {
            obj.promjena(textBox_Ime.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox_Ime.Text = this.Text;
        }

        private void button_Dodaj_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            obj.promijeniIme += f.PromijeniIme;
            f.Show();
        }
    }
}
