﻿namespace Room_Management
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.opcijeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prijavaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.odjavaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listBox_Rezervacije = new System.Windows.Forms.ListBox();
            this.label_Rezervacije = new System.Windows.Forms.Label();
            this.monthCalendar_Datum = new System.Windows.Forms.MonthCalendar();
            this.label_Prostorija = new System.Windows.Forms.Label();
            this.comboBox_Prostorije = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 9F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.opcijeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(933, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // opcijeToolStripMenuItem
            // 
            this.opcijeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prijavaToolStripMenuItem,
            this.odjavaToolStripMenuItem});
            this.opcijeToolStripMenuItem.Name = "opcijeToolStripMenuItem";
            this.opcijeToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.opcijeToolStripMenuItem.Text = "Opcije";
            // 
            // prijavaToolStripMenuItem
            // 
            this.prijavaToolStripMenuItem.Name = "prijavaToolStripMenuItem";
            this.prijavaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.prijavaToolStripMenuItem.Text = "Prijava";
            this.prijavaToolStripMenuItem.Click += new System.EventHandler(this.prijavaToolStripMenuItem_Click);
            // 
            // odjavaToolStripMenuItem
            // 
            this.odjavaToolStripMenuItem.Name = "odjavaToolStripMenuItem";
            this.odjavaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.odjavaToolStripMenuItem.Text = "Odjava";
            // 
            // listBox_Rezervacije
            // 
            this.listBox_Rezervacije.FormattingEnabled = true;
            this.listBox_Rezervacije.ItemHeight = 14;
            this.listBox_Rezervacije.Location = new System.Drawing.Point(14, 278);
            this.listBox_Rezervacije.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.listBox_Rezervacije.Name = "listBox_Rezervacije";
            this.listBox_Rezervacije.Size = new System.Drawing.Size(905, 144);
            this.listBox_Rezervacije.TabIndex = 2;
            // 
            // label_Rezervacije
            // 
            this.label_Rezervacije.AutoSize = true;
            this.label_Rezervacije.Location = new System.Drawing.Point(14, 261);
            this.label_Rezervacije.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Rezervacije.Name = "label_Rezervacije";
            this.label_Rezervacije.Size = new System.Drawing.Size(38, 14);
            this.label_Rezervacije.TabIndex = 3;
            this.label_Rezervacije.Text = "label1";
            // 
            // monthCalendar_Datum
            // 
            this.monthCalendar_Datum.Location = new System.Drawing.Point(18, 36);
            this.monthCalendar_Datum.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.monthCalendar_Datum.MaxSelectionCount = 1;
            this.monthCalendar_Datum.Name = "monthCalendar_Datum";
            this.monthCalendar_Datum.TabIndex = 4;
            this.monthCalendar_Datum.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar_Datum_DateChanged);
            // 
            // label_Prostorija
            // 
            this.label_Prostorija.AutoSize = true;
            this.label_Prostorija.Location = new System.Drawing.Point(14, 232);
            this.label_Prostorija.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Prostorija.Name = "label_Prostorija";
            this.label_Prostorija.Size = new System.Drawing.Size(61, 14);
            this.label_Prostorija.TabIndex = 5;
            this.label_Prostorija.Text = "Prostorija:";
            // 
            // comboBox_Prostorije
            // 
            this.comboBox_Prostorije.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Prostorije.FormattingEnabled = true;
            this.comboBox_Prostorije.Location = new System.Drawing.Point(83, 228);
            this.comboBox_Prostorije.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBox_Prostorije.Name = "comboBox_Prostorije";
            this.comboBox_Prostorije.Size = new System.Drawing.Size(140, 22);
            this.comboBox_Prostorije.TabIndex = 6;
            this.comboBox_Prostorije.SelectedIndexChanged += new System.EventHandler(this.comboBox_Prostorije_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 485);
            this.Controls.Add(this.comboBox_Prostorije);
            this.Controls.Add(this.label_Prostorija);
            this.Controls.Add(this.monthCalendar_Datum);
            this.Controls.Add(this.label_Rezervacije);
            this.Controls.Add(this.listBox_Rezervacije);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 9F);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Management";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem opcijeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prijavaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem odjavaToolStripMenuItem;
        private System.Windows.Forms.ListBox listBox_Rezervacije;
        private System.Windows.Forms.Label label_Rezervacije;
        private System.Windows.Forms.MonthCalendar monthCalendar_Datum;
        private System.Windows.Forms.Label label_Prostorija;
        private System.Windows.Forms.ComboBox comboBox_Prostorije;
    }
}

