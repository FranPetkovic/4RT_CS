﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SkolslkiKurikulum;
using System.Windows.Forms;
using System.Diagnostics;

namespace Room_Management
{
    public class CRezervacija
    {
        private static String connStr = @"server=localhost\SQLEXPRESS;uid=room_mng;pwd=12345;database=room_management";
        private static List<CRezervacija> Rezervacije = new List<CRezervacija>();
        private int ID;
        private CKorisnik Korisnik;
        private CVremena Pocetak, Kraj;
        private CProstorija Prostorija;
        private CPonavljanje Ponavljanje;
        private bool Aktivno;

        private CRezervacija(int iD, CKorisnik korisnik, CVremena pocetak, CVremena kraj, CProstorija prostorija, CPonavljanje ponavljanje, bool aktivno)
        {
            ID = iD;
            Korisnik = korisnik;
            Pocetak = pocetak;
            Kraj = kraj;
            Prostorija = prostorija;
            Ponavljanje = ponavljanje;
            Aktivno = aktivno;
        }

        public static void dohvatiRezervacije(DateTime Datum)
        {
            Rezervacije.Clear();
            SqlConnection myConnection = new SqlConnection(connStr);
            SqlDataReader myReader = null;
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand("select * from Rezervacije where Datum = '" + Datum.ToString("yyyy-MM-dd")  + "' AND Aktivno = 'True'", myConnection);
            try
            {
                myReader = myCommand.ExecuteReader();

                while (myReader.Read())
                {
                    Rezervacije.Add(new CRezervacija(
                        myReader.GetInt32(0),
                        CKorisnik.vratiKorisnikaPoIDu(myReader.GetInt32(2)),
                        CVremena.vratiVrijemePoIDu(myReader.GetInt32(3)),
                        CVremena.vratiVrijemePoIDu(myReader.GetInt32(4)),
                        CProstorija.vratiProstorijuPoIDu(myReader.GetInt32(5)),
                        CPonavljanje.vratiPonavljanjePoIDu(myReader.GetInt32(6)),
                        myReader.GetBoolean(7)
                        ));
                }

            }
            catch
            {
                MessageBox.Show("Greška pri dohvaćanju Rezervacija iz baze", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            myConnection.Close();
        }


        public static List<CRezervacija> vratiRezervacijuPoProstoriji(CProstorija prostorija)
        {
            List<CRezervacija> RezervacijeTemp = new List<CRezervacija>();

            foreach (CRezervacija r in Rezervacije)
            {
                if (r.Prostorija.ToString().Equals(prostorija.ToString()))
                {
                    RezervacijeTemp.Add(r);
                }
            }

            return RezervacijeTemp;
        }

        public static List<CRezervacija> vratiRezervacije()
        {
            return Rezervacije;
        }

        public override string ToString()
        {
            return Prostorija + "\t" + Pocetak + " - " + Kraj + "\t" + Ponavljanje + "\t" + Korisnik.vratiPunoIme();
        }
    }
}
