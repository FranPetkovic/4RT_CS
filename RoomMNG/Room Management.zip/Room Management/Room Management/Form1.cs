﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using SkolslkiKurikulum;

namespace Room_Management
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //string str = "";

            //CPravo.dohvatiPrava();
            //foreach(CPravo p in CPravo.vratiPrava())
            //{
            //    str += p + "\n";
            //}



            //MessageBox.Show((str));
            
        }

        private void prijavaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ucitajProstorije()
        {
            comboBox_Prostorije.Items.Clear();

            comboBox_Prostorije.Items.Add("Sve");
            foreach (CProstorija p in CProstorija.vratiProstorije())
                comboBox_Prostorije.Items.Add(p);

            comboBox_Prostorije.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PrijavaForm form = new PrijavaForm();
            if(form.ShowDialog() == DialogResult.OK)
            {
                CPravo.dohvatiPrava();
                CProstorija.dohvatiProstorije();
                ucitajProstorije();
                CVremena.dohvatiVremena();
                CPonavljanje.dohvatiPonavljanja();
                CKorisnik.dohvatiKorisnike();
                CRezervacija.dohvatiRezervacije(monthCalendar_Datum.SelectionRange.Start);
                label_Rezervacije.Text = "Prostorija\tPocetak - Kraj\tPonavljanje\tRezervirao".Replace("\t", "    "); ;
                listBox_Rezervacije.Items.Clear();
                foreach (CRezervacija r in CRezervacija.vratiRezervacije())
                    listBox_Rezervacije.Items.Add(r);
            }
            else
            {
                CProstorija.dohvatiProstorije();
                ucitajProstorije();
                CVremena.dohvatiVremena();
                CPonavljanje.dohvatiPonavljanja();
                CKorisnik.dohvatiKorisnike();
                CRezervacija.dohvatiRezervacije(monthCalendar_Datum.SelectionRange.Start);
                label_Rezervacije.Text = "Prostorija\tPocetak - Kraj\tPonavljanje\tRezervirao".Replace("\t", "    "); ;
                listBox_Rezervacije.Items.Clear();
                foreach (CRezervacija r in CRezervacija.vratiRezervacije())
                    listBox_Rezervacije.Items.Add(r);
                listBox_Rezervacije.Enabled = false;
            }
        }

        private void ucitajRezervacije()
        {
            listBox_Rezervacije.Items.Clear();

            if (comboBox_Prostorije.SelectedIndex == 0) // Sve Rezervacije
            {
                if (CRezervacija.vratiRezervacije().Count == 0)
                {
                    listBox_Rezervacije.Items.Add("Nema Rezervacija");
                    listBox_Rezervacije.Enabled = false;
                    return;
                }
                foreach (CRezervacija r in CRezervacija.vratiRezervacije())
                    listBox_Rezervacije.Items.Add(r);
                listBox_Rezervacije.Enabled = true;
            }
            else
            {
                if (CRezervacija.vratiRezervacijuPoProstoriji((CProstorija)comboBox_Prostorije.SelectedItem).Count == 0)
                {
                    listBox_Rezervacije.Items.Add("Nema Rezervacija");
                    listBox_Rezervacije.Enabled = false;
                    return;
                }
                foreach (CRezervacija r in CRezervacija.vratiRezervacijuPoProstoriji((CProstorija)comboBox_Prostorije.SelectedItem))
                    listBox_Rezervacije.Items.Add(r);
                listBox_Rezervacije.Enabled = true;
            }
        }

        private void monthCalendar_Datum_DateChanged(object sender, DateRangeEventArgs e)
        {
            CRezervacija.dohvatiRezervacije(monthCalendar_Datum.SelectionRange.Start);
            ucitajRezervacije();
        }

        private void comboBox_Prostorije_SelectedIndexChanged(object sender, EventArgs e)
        {
            ucitajRezervacije();
        }
    }
}
