﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SkolslkiKurikulum;
using System.Windows.Forms;

namespace Room_Management
{
    public class CVremena
    {
        private static String connStr = @"server=localhost\SQLEXPRESS;uid=room_mng;pwd=12345;database=room_management";

        private static List<CVremena> Vremena = new List<CVremena>();
        private int ID;
        private DateTime Pocetak;

        private CVremena(int iD, DateTime pocetak)
        {
            ID = iD;
            Pocetak = pocetak;
        }

        public static void dohvatiVremena()
        {
            Vremena.Clear();
            SqlConnection myConnection = new SqlConnection(connStr);
            SqlDataReader myReader = null;
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand("select * from Vremena", myConnection);
            try
            {
                myReader = myCommand.ExecuteReader();

                while (myReader.Read())
                {
                    Vremena.Add(new CVremena(
                        myReader.GetInt32(0),
                        myReader.GetDateTime(1)));
                }

            }
            catch
            {
                MessageBox.Show("Greška pri dohvaćanju Vremena iz baze", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            myConnection.Close();
        }

        public static CVremena vratiVrijemePoIDu(int ID)
        {
            foreach (CVremena v in Vremena)
                if (v.ID == ID)
                    return v;
            return null;
        }

        public override string ToString()
        {
            return Pocetak.ToString("HH:mm");
        }
    }
}
