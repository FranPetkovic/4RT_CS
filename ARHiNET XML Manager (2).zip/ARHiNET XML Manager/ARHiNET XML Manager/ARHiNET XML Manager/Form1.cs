﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Schema;
using System.IO;
using static ARHiNET_XML_Manager.Form1.RegistraturnaJedinica;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ARHiNET_XML_Manager {

    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        public class RegistraturnaJedinica {
            public int RazinaId { get; set; }
            public int Signatura { get; set; }
            public string Naziv { get; set; }
            public int GodinaOd { get; set; }
            public int GodinaDo { get; set; }
            public int ImateljId { get; set; }
            public string NapomenaORazdoblju { get; set; }
            public string Sadrzaj { get; set; }
            public string Napomena { get; set; }
            public Oznaka oznaka { get; set; }
            public Stvaratelj stvaratelj { get; set; }
            public Gradja gradja { get; set; }
            public Medij medij { get; set; }
            public Kolicina KolicinaArhivskihJedinica { get; set; }
            public Kolicina KolicinaTehnickihJedinica { get; set; }
            public RegistraturnaJedinica registraturnaJedinica { get; set; }

            public class Oznaka {
                public int VrstaOstaleOznakeId { get; set; }
                public string Naziv { get; set; }
            }

            public class Stvaratelj {
                public int StvarateljId { get; set; }
                public int UlogaId { get; set; }
                public string Razdoblje { get; set; }
                public string NapomenaOStvaratelju { get; set; }
            }

            public class Gradja {
                public int KomPodvrstaId { get; set; }
            }

            public class Medij {
                public int VrstaMedijaId { get; set; }
            }

            public class Kolicina {
                public int MjernaJedinicaId { get; set; }
                public double kolicina { get; set; }
                public TvarneZnacajke TvarneZnacajke { get; set; }
            }

            public class TvarneZnacajke {
                public string Opis { get; set; }
            }

        }

        public class ComboBoxItem {
            public int RazinaId { get; set; }
            public int Signatura { get; set; }
            public string Naziv { get; set; }
            public int GodinaOd { get; set; }
            public int GodinaDo { get; set; }
            public int ImateljId { get; set; }
            public string NapomenaORazdoblju { get; set; }
            public string Sadrzaj { get; set; }
            public string Napomena { get; set; }
            public Oznaka Oznaka { get; set; }
            public Stvaratelj Stvaratelj { get; set; }
            public Gradja Gradja { get; set; }
            public Medij Medij { get; set; }
            public Kolicina KolicinaArhivskihJedinica { get; set; }
            public Kolicina KolicinaTehnickihJedinica { get; set; }
            public RegistraturnaJedinica RegistraturnaJedinica { get; set; }

            public override string ToString() {
                return Naziv; // Display the 'Naziv' property in the ComboBox
            }
        }

        private void PopulateComboBox() {
            // Create instances of ComboBoxItem and add them to the ComboBox
            var items = new List<ComboBoxItem>
            {
                new ComboBoxItem { RazinaId = 1, Signatura = 123, Naziv = "Item 1" },
                new ComboBoxItem { RazinaId = 2, Signatura = 456, Naziv = "Item 2" },
                        // Add more items as needed
            };

            comboBox.Items.AddRange(items.ToArray());
        }

        private void Form1_Load(object sender, EventArgs e) {
            RegistraturnaJedinica r = new RegistraturnaJedinica();
            r.Naziv = "RegistraturnaJedinica";

            treeViewXml.Nodes.Clear();

            TreeNode treeNode = new TreeNode(r.Naziv);
            treeNode.Tag = r;

            treeViewXml.Nodes.Add(treeNode);

            PopulateComboBox(); 
        }

        private void btnAddNode_Click(object sender, EventArgs e) {

        }



        private void btnSave_Click(object sender, EventArgs e) {

        }

        private void napomenaORazdobljuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.NapomenaORazdoblju = "NapomenaORazdoblju";
                    TreeNode treeNode = new TreeNode(r.NapomenaORazdoblju);
                    treeNode.Tag = r.NapomenaORazdoblju;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void sadrzajToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.Sadrzaj = "Sadrzaj";
                    TreeNode treeNode = new TreeNode(r.Sadrzaj);
                    treeNode.Tag = r.Sadrzaj;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void napomenaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.Napomena = "Napomena";
                    TreeNode treeNode = new TreeNode(r.Napomena);
                    treeNode.Tag = r.Napomena;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void oznakaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.oznaka = new Oznaka();
                    r.oznaka.Naziv = "Oznaka";
                    TreeNode treeNode = new TreeNode(r.oznaka.Naziv);
                    treeNode.Tag = r.oznaka;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void stvarateljToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.stvaratelj = new Stvaratelj();
                    r.stvaratelj.NapomenaOStvaratelju = "NapomenaOStvaratelju";
                    TreeNode treeNode = new TreeNode(r.oznaka.Naziv);
                    treeNode.Tag = r.oznaka;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void treeViewXml_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    contextMenuStrip1.Items.Add("NapomenaORazdoblju");
                    contextMenuStrip1.Items[0].Click += napomenaORazdobljuToolStripMenuItem_Click;
                    contextMenuStrip1.Items.Add("Sadrzaj");
                    contextMenuStrip1.Items[1].Click += sadrzajToolStripMenuItem_Click;
                    contextMenuStrip1.Items.Add("Napomena");
                    contextMenuStrip1.Items[2].Click += sadrzajToolStripMenuItem_Click;
                    contextMenuStrip1.Items.Add("Oznaka");
                    contextMenuStrip1.Items[3].Click += oznakaToolStripMenuItem_Click;
                    contextMenuStrip1.Items.Add("Stvaratelj");
                    contextMenuStrip1.Items[4].Click += stvarateljToolStripMenuItem_Click;
                    contextMenuStrip1.Items.Add("Gradja");
                    contextMenuStrip1.Items.Add("Medij");
                    contextMenuStrip1.Items.Add("KolicinaArhivskihJedinica");
                    contextMenuStrip1.Items.Add("KolicinaTehnickihJedinica");
                    contextMenuStrip1.Items.Add("RegistraturnaJedinica");
                }
            }
        }
    }
}
