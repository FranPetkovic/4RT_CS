﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SlideshowManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            refresh();
        }

        void refresh()
        {
            listBoxFiles.Items.Clear();
            string ftpServer = @"ftp://192.168.42.89:8021/";
            string ftpUsername = "admin";
            string ftpPassword = "admin";

            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpServer);
            request.Method = WebRequestMethods.Ftp.ListDirectory;
            request.Credentials = new NetworkCredential(ftpUsername, ftpPassword);

            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                while (!reader.EndOfStream)
                {
                    listBoxFiles.Items.Add(reader.ReadLine());
                }
            }
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.InitialDirectory = "c:\\";
                ofd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                ofd.FilterIndex = 2;
                ofd.RestoreDirectory = true;
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    textBoxPath.Text = ofd.FileName;
                }
            }
        }

        private void buttonDownload_Click(object sender, EventArgs e)
        {
            string ftpServer = @"ftp://192.168.42.89:8021/";
            string ftpUsername = "admin";
            string ftpPassword = "admin";

            string path = Path.GetDirectoryName(Environment.GetFolderPath(Environment.SpecialFolder.Personal)); path = Path.Combine(path, "Downloads");

            string localFilePath = path + @"\" + listBoxFiles.SelectedItem.ToString();


            string remoteFilePath = listBoxFiles.SelectedItem.ToString();

            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpServer + remoteFilePath);
            request.Method = WebRequestMethods.Ftp.DownloadFile;
            request.Credentials = new NetworkCredential(ftpUsername, ftpPassword);

            using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
            using (Stream ftpStream = response.GetResponseStream())
            using (FileStream localFileStream = new FileStream(localFilePath, FileMode.Create))
            {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = ftpStream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    localFileStream.Write(buffer, 0, bytesRead);
                }
            }
        }

        private void buttonUpload_Click(object sender, EventArgs e)
        {
            string ftpServer = @"ftp://192.168.42.89:8021/";
            string ftpUsername = "admin";
            string ftpPassword = "admin";
            string localFilePath = textBoxPath.Text;
            string remoteFilePath = textBoxPath.Text.Substring(textBoxPath.Text.LastIndexOf(@"\") + 1, textBoxPath.Text.Length - textBoxPath.Text.LastIndexOf(@"\") - 1);


            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ftpServer + remoteFilePath);
            request.Method = WebRequestMethods.Ftp.UploadFile;
            request.Credentials = new NetworkCredential(ftpUsername, ftpPassword);

            using (Stream fileStream = File.OpenRead(localFilePath))
            using (Stream ftpStream = request.GetRequestStream())
            {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ftpStream.Write(buffer, 0, bytesRead);
                }
            }

            refresh();
        }
    }
}
