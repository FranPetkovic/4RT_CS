﻿namespace ARHiNET_XML_Manager {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TreeView treeViewXml;


        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.treeViewXml = new System.Windows.Forms.TreeView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dodajToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.promijeniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obrisiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelData = new System.Windows.Forms.Panel();
            this.panelRegistraturnaJedinica = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_RegistraturnaJedinicaNaziv = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_RegistraturnaJedinicaGodinaOd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_RegistraturnaJedinicaGodinaDo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_RegistraturnaJedinicaImateljId = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_Napomena = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox_Sadrzaj = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panelNapomenaORazdoblju = new System.Windows.Forms.Panel();
            this.textBox_NapomenaORazdoblju = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.contextMenuStrip1.SuspendLayout();
            this.panelData.SuspendLayout();
            this.panelRegistraturnaJedinica.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelNapomenaORazdoblju.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeViewXml
            // 
            this.treeViewXml.ContextMenuStrip = this.contextMenuStrip1;
            this.treeViewXml.Location = new System.Drawing.Point(12, 12);
            this.treeViewXml.Name = "treeViewXml";
            this.treeViewXml.Size = new System.Drawing.Size(300, 426);
            this.treeViewXml.TabIndex = 0;
            this.treeViewXml.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewXml_AfterSelect);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dodajToolStripMenuItem,
            this.promijeniToolStripMenuItem,
            this.obrisiToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(126, 70);
            // 
            // dodajToolStripMenuItem
            // 
            this.dodajToolStripMenuItem.Name = "dodajToolStripMenuItem";
            this.dodajToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.dodajToolStripMenuItem.Text = "Dodaj";
            // 
            // promijeniToolStripMenuItem
            // 
            this.promijeniToolStripMenuItem.Name = "promijeniToolStripMenuItem";
            this.promijeniToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.promijeniToolStripMenuItem.Text = "Promijeni";
            // 
            // obrisiToolStripMenuItem
            // 
            this.obrisiToolStripMenuItem.Name = "obrisiToolStripMenuItem";
            this.obrisiToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.obrisiToolStripMenuItem.Text = "Obrisi";
            // 
            // panelData
            // 
            this.panelData.Controls.Add(this.panel3);
            this.panelData.Controls.Add(this.panel2);
            this.panelData.Controls.Add(this.panel1);
            this.panelData.Controls.Add(this.panelNapomenaORazdoblju);
            this.panelData.Controls.Add(this.panelRegistraturnaJedinica);
            this.panelData.Enabled = false;
            this.panelData.Location = new System.Drawing.Point(318, 12);
            this.panelData.Name = "panelData";
            this.panelData.Size = new System.Drawing.Size(470, 426);
            this.panelData.TabIndex = 1;
            // 
            // panelRegistraturnaJedinica
            // 
            this.panelRegistraturnaJedinica.Controls.Add(this.textBox_RegistraturnaJedinicaGodinaDo);
            this.panelRegistraturnaJedinica.Controls.Add(this.label4);
            this.panelRegistraturnaJedinica.Controls.Add(this.textBox_RegistraturnaJedinicaImateljId);
            this.panelRegistraturnaJedinica.Controls.Add(this.label5);
            this.panelRegistraturnaJedinica.Controls.Add(this.textBox_RegistraturnaJedinicaGodinaOd);
            this.panelRegistraturnaJedinica.Controls.Add(this.label3);
            this.panelRegistraturnaJedinica.Controls.Add(this.textBox_RegistraturnaJedinicaNaziv);
            this.panelRegistraturnaJedinica.Controls.Add(this.label2);
            this.panelRegistraturnaJedinica.Location = new System.Drawing.Point(6, 3);
            this.panelRegistraturnaJedinica.Name = "panelRegistraturnaJedinica";
            this.panelRegistraturnaJedinica.Size = new System.Drawing.Size(461, 50);
            this.panelRegistraturnaJedinica.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Naziv:";
            // 
            // textBox_RegistraturnaJedinicaNaziv
            // 
            this.textBox_RegistraturnaJedinicaNaziv.Location = new System.Drawing.Point(67, 4);
            this.textBox_RegistraturnaJedinicaNaziv.Name = "textBox_RegistraturnaJedinicaNaziv";
            this.textBox_RegistraturnaJedinicaNaziv.Size = new System.Drawing.Size(132, 20);
            this.textBox_RegistraturnaJedinicaNaziv.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "GodinaOd:";
            // 
            // textBox_RegistraturnaJedinicaGodinaOd
            // 
            this.textBox_RegistraturnaJedinicaGodinaOd.Location = new System.Drawing.Point(67, 30);
            this.textBox_RegistraturnaJedinicaGodinaOd.Name = "textBox_RegistraturnaJedinicaGodinaOd";
            this.textBox_RegistraturnaJedinicaGodinaOd.Size = new System.Drawing.Size(132, 20);
            this.textBox_RegistraturnaJedinicaGodinaOd.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(213, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "GodinaDo:";
            // 
            // textBox_RegistraturnaJedinicaGodinaDo
            // 
            this.textBox_RegistraturnaJedinicaGodinaDo.Location = new System.Drawing.Point(277, 4);
            this.textBox_RegistraturnaJedinicaGodinaDo.Name = "textBox_RegistraturnaJedinicaGodinaDo";
            this.textBox_RegistraturnaJedinicaGodinaDo.Size = new System.Drawing.Size(132, 20);
            this.textBox_RegistraturnaJedinicaGodinaDo.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(213, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "ImateljId:";
            // 
            // textBox_RegistraturnaJedinicaImateljId
            // 
            this.textBox_RegistraturnaJedinicaImateljId.Location = new System.Drawing.Point(277, 30);
            this.textBox_RegistraturnaJedinicaImateljId.Name = "textBox_RegistraturnaJedinicaImateljId";
            this.textBox_RegistraturnaJedinicaImateljId.Size = new System.Drawing.Size(132, 20);
            this.textBox_RegistraturnaJedinicaImateljId.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox_Napomena);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(6, 133);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(461, 31);
            this.panel2.TabIndex = 3;
            // 
            // textBox_Napomena
            // 
            this.textBox_Napomena.Location = new System.Drawing.Point(67, 6);
            this.textBox_Napomena.Name = "textBox_Napomena";
            this.textBox_Napomena.Size = new System.Drawing.Size(132, 20);
            this.textBox_Napomena.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Napomena:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox_Sadrzaj);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(6, 96);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(461, 31);
            this.panel1.TabIndex = 4;
            // 
            // textBox_Sadrzaj
            // 
            this.textBox_Sadrzaj.Location = new System.Drawing.Point(56, 6);
            this.textBox_Sadrzaj.Name = "textBox_Sadrzaj";
            this.textBox_Sadrzaj.Size = new System.Drawing.Size(132, 20);
            this.textBox_Sadrzaj.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Sadrzaj:";
            // 
            // panelNapomenaORazdoblju
            // 
            this.panelNapomenaORazdoblju.Controls.Add(this.textBox_NapomenaORazdoblju);
            this.panelNapomenaORazdoblju.Controls.Add(this.label6);
            this.panelNapomenaORazdoblju.Location = new System.Drawing.Point(6, 59);
            this.panelNapomenaORazdoblju.Name = "panelNapomenaORazdoblju";
            this.panelNapomenaORazdoblju.Size = new System.Drawing.Size(461, 31);
            this.panelNapomenaORazdoblju.TabIndex = 5;
            // 
            // textBox_NapomenaORazdoblju
            // 
            this.textBox_NapomenaORazdoblju.Location = new System.Drawing.Point(126, 6);
            this.textBox_NapomenaORazdoblju.Name = "textBox_NapomenaORazdoblju";
            this.textBox_NapomenaORazdoblju.Size = new System.Drawing.Size(132, 20);
            this.textBox_NapomenaORazdoblju.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "NapomenaORazdoblju:";
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(6, 170);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(461, 84);
            this.panel3.TabIndex = 6;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelData);
            this.Controls.Add(this.treeViewXml);
            this.Name = "Form1";
            this.Text = "XML Editor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.panelData.ResumeLayout(false);
            this.panelRegistraturnaJedinica.ResumeLayout(false);
            this.panelRegistraturnaJedinica.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelNapomenaORazdoblju.ResumeLayout(false);
            this.panelNapomenaORazdoblju.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dodajToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem promijeniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obrisiToolStripMenuItem;
        private System.Windows.Forms.Panel panelData;
        private System.Windows.Forms.Panel panelRegistraturnaJedinica;
        private System.Windows.Forms.TextBox textBox_RegistraturnaJedinicaNaziv;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_RegistraturnaJedinicaGodinaDo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_RegistraturnaJedinicaGodinaOd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_RegistraturnaJedinicaImateljId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox_Napomena;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_Sadrzaj;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panelNapomenaORazdoblju;
        private System.Windows.Forms.TextBox textBox_NapomenaORazdoblju;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
    }
}

