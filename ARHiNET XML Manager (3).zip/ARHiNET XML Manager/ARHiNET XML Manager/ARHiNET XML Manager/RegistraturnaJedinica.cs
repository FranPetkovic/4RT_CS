﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ARHiNET_XML_Manager {
    public class RegistraturnaJedinica {
        private int RazinaId, Signatura, GodinaOd, GodinaDo, ImateljId;
        private string Naziv;
    }
}
