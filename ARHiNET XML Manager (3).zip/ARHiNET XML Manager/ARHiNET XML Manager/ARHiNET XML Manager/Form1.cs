﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Schema;
using System.IO;
using static ARHiNET_XML_Manager.Form1.RegistraturnaJedinica;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ARHiNET_XML_Manager {

    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        public class RegistraturnaJedinica {
            public int RazinaId { get; set; }
            public int Signatura { get; set; }
            public int brojSignatura { get; set; }
            public string Naziv { get; set; }
            public int GodinaOd { get; set; }
            public int GodinaDo { get; set; }
            public int ImateljId { get; set; }
            public string NapomenaORazdoblju { get; set; }
            public string Sadrzaj { get; set; }
            public string Napomena { get; set; }
            public Oznaka oznaka { get; set; }
            public Stvaratelj stvaratelj { get; set; }
            public Gradja gradja { get; set; }
            public Medij medij { get; set; }
            public Kolicina KolicinaArhivskihJedinica { get; set; }
            public Kolicina KolicinaTehnickihJedinica { get; set; }
            public RegistraturnaJedinica registraturnaJedinica { get; set; }

            public class Oznaka {
                public int VrstaOstaleOznakeId { get; set; }
                public string Naziv { get; set; }
            }

            public class Stvaratelj {
                public int StvarateljId { get; set; }
                public int UlogaId { get; set; }
                public string Razdoblje { get; set; }
                public string NapomenaOStvaratelju { get; set; }
            }

            public class Gradja {
                public int KomPodvrstaId { get; set; }
            }

            public class Medij {
                public int VrstaMedijaId { get; set; }
            }

            public class Kolicina {
                public int MjernaJedinicaId { get; set; }
                public double kolicina { get; set; }
                public TvarneZnacajke TvarneZnacajke { get; set; }
            }

            public class TvarneZnacajke {
                public string Opis { get; set; }
            }

        }

       

        private void Form1_Load(object sender, EventArgs e) {
            RegistraturnaJedinica r = new RegistraturnaJedinica();
            r.RazinaId = 0;
            r.Signatura = 1;
            r.brojSignatura = 0;
            r.Naziv = "RegistraturnaJedinica";
            r.GodinaOd = 2022;
            r.GodinaDo = 2023;
            r.ImateljId = 0;

            treeViewXml.Nodes.Clear();

            TreeNode treeNode = new TreeNode(r.RazinaId + "." + r.Signatura + ". " + "RegistraturnaJedinica");
            treeNode.Tag = r;

            treeViewXml.Nodes.Add(treeNode);
        }

        private void napomenaORazdobljuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.NapomenaORazdoblju = "NapomenaORazdoblju";
                    TreeNode treeNode = new TreeNode("NapomenaORazdoblju");
                    treeNode.Tag = r.NapomenaORazdoblju;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void sadrzajToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.Sadrzaj = "Sadrzaj";
                    TreeNode treeNode = new TreeNode("Sadrzaj");
                    treeNode.Tag = r.Sadrzaj;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void napomenaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.Napomena = "Napomena";
                    TreeNode treeNode = new TreeNode("Napomena");
                    treeNode.Tag = r.Napomena;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void oznakaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.oznaka = new Oznaka();
                    r.oznaka.VrstaOstaleOznakeId = 0;
                    r.oznaka.Naziv = "Oznaka";
                    TreeNode treeNode = new TreeNode("Oznaka");
                    treeNode.Tag = r.oznaka;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void stvarateljToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.stvaratelj = new Stvaratelj();
                    r.stvaratelj.UlogaId = 0;
                    r.stvaratelj.StvarateljId = 0;
                    r.stvaratelj.Razdoblje = "Razdoblje";
                    r.stvaratelj.NapomenaOStvaratelju = "NapomenaOStvaratelju";
                    TreeNode treeNode = new TreeNode("Stvaratelj");
                    treeNode.Tag = r.stvaratelj;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void gradjaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.gradja = new Gradja();
                    r.gradja.KomPodvrstaId = 0;
                    TreeNode treeNode = new TreeNode("Gradja");
                    treeNode.Tag = r.gradja;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }
        
        private void medijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.medij = new Medij();
                    r.medij.VrstaMedijaId = 0;
                    TreeNode treeNode = new TreeNode("Medij");
                    treeNode.Tag = r.medij;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }
        private void kolicinaArhivskihJedinicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.KolicinaArhivskihJedinica = new Kolicina();
                    r.KolicinaArhivskihJedinica.MjernaJedinicaId = 0;
                    r.KolicinaArhivskihJedinica.kolicina = 0.0f;
                    r.KolicinaArhivskihJedinica.TvarneZnacajke = new TvarneZnacajke();
                    r.KolicinaArhivskihJedinica.TvarneZnacajke.Opis = "Opis";
                    TreeNode treeNode = new TreeNode("KolicinaArhivskihJedinica");
                    treeNode.Tag = r.KolicinaArhivskihJedinica;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void kolicinaTehnickihJedinicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.KolicinaTehnickihJedinica = new Kolicina();
                    r.KolicinaTehnickihJedinica.MjernaJedinicaId = 0;
                    r.KolicinaTehnickihJedinica.kolicina = 0.0f;
                    r.KolicinaTehnickihJedinica.TvarneZnacajke = new TvarneZnacajke();
                    r.KolicinaTehnickihJedinica.TvarneZnacajke.Opis = "Opis";
                    TreeNode treeNode = new TreeNode("KolicinaTehnickihJedinica");
                    treeNode.Tag = r.KolicinaTehnickihJedinica;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void registraturnaJedinicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    r.registraturnaJedinica = new RegistraturnaJedinica();
                    r.registraturnaJedinica.RazinaId = r.RazinaId + 1;
                    r.registraturnaJedinica.Signatura = r.Signatura + r.brojSignatura;
                    r.brojSignatura++;
                    r.registraturnaJedinica.Naziv = "RegistraturnaJedinica";
                    r.registraturnaJedinica.GodinaOd = 2022;
                    r.registraturnaJedinica.GodinaDo = 2023;
                    r.registraturnaJedinica.ImateljId = 0;
                    TreeNode treeNode = new TreeNode(r.registraturnaJedinica.RazinaId + "." + r.registraturnaJedinica.Signatura + ". " + "RegistraturnaJedinica");
                    treeNode.Tag = r.registraturnaJedinica;
                    selectedNode.Nodes.Add(treeNode);
                }
            }
        }

        private void treeViewXml_AfterSelect(object sender, TreeViewEventArgs e)
        {
            dodajToolStripMenuItem.DropDownItems.Clear();
            dodajToolStripMenuItem.Enabled = true;

            TreeNode selectedNode = treeViewXml.SelectedNode;

            if (selectedNode != null)
            {
                if (selectedNode?.Tag is RegistraturnaJedinica reg)
                {
                    int index = 0;
                    RegistraturnaJedinica r = (selectedNode?.Tag as RegistraturnaJedinica);
                    dodajToolStripMenuItem.DropDownItems.Add("NapomenaORazdoblju");
                    dodajToolStripMenuItem.DropDownItems[index].Click += napomenaORazdobljuToolStripMenuItem_Click;
                    index++;
                    dodajToolStripMenuItem.DropDownItems.Add("Sadrzaj");
                    dodajToolStripMenuItem.DropDownItems[index].Click += sadrzajToolStripMenuItem_Click;                    
                    index++;
                    dodajToolStripMenuItem.DropDownItems.Add("Napomena");
                    dodajToolStripMenuItem.DropDownItems[index].Click += napomenaToolStripMenuItem_Click;
                    index++;
                    dodajToolStripMenuItem.DropDownItems.Add("Oznaka");
                    dodajToolStripMenuItem.DropDownItems[index].Click += oznakaToolStripMenuItem_Click;
                    index++;
                    if (r.RazinaId == 0 && r.stvaratelj == null)
                    {
                        dodajToolStripMenuItem.DropDownItems.Add("Stvaratelj");
                        dodajToolStripMenuItem.DropDownItems[index].Click += stvarateljToolStripMenuItem_Click;
                        index++;
                    }
                    dodajToolStripMenuItem.DropDownItems.Add("Gradja");
                    dodajToolStripMenuItem.DropDownItems[index].Click += gradjaToolStripMenuItem_Click;
                    index++;
                    dodajToolStripMenuItem.DropDownItems.Add("Medij");
                    dodajToolStripMenuItem.DropDownItems[index].Click += medijToolStripMenuItem_Click;
                    index++;
                    dodajToolStripMenuItem.DropDownItems.Add("KolicinaArhivskihJedinica");
                    dodajToolStripMenuItem.DropDownItems[index].Click += kolicinaArhivskihJedinicaToolStripMenuItem_Click;
                    index++;
                    dodajToolStripMenuItem.DropDownItems.Add("KolicinaTehnickihJedinica");
                    dodajToolStripMenuItem.DropDownItems[index].Click += kolicinaTehnickihJedinicaToolStripMenuItem_Click;
                    index++;
                    dodajToolStripMenuItem.DropDownItems.Add("RegistraturnaJedinica");
                    dodajToolStripMenuItem.DropDownItems[index].Click += registraturnaJedinicaToolStripMenuItem_Click;
                    index++;
                }
                else
                {
                    dodajToolStripMenuItem.Enabled = false;
                }
            }
        }
    }
}
