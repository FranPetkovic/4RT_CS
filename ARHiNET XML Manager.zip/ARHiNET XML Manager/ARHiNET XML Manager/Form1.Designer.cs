﻿namespace ARHiNET_XML_Manager {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TreeView treeViewXml;
        private System.Windows.Forms.Label lblNodeName;
        private System.Windows.Forms.Label lblNodeValue;
        private System.Windows.Forms.TextBox txtNodeName;
        private System.Windows.Forms.TextBox txtNodeValue;
        private System.Windows.Forms.Button btnAddNode;
        private System.Windows.Forms.Button btnSave;


        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.treeViewXml = new System.Windows.Forms.TreeView();
            this.lblNodeName = new System.Windows.Forms.Label();
            this.lblNodeValue = new System.Windows.Forms.Label();
            this.txtNodeName = new System.Windows.Forms.TextBox();
            this.txtNodeValue = new System.Windows.Forms.TextBox();
            this.btnAddNode = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dodajToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.promijeniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obrisiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeViewXml
            // 
            this.treeViewXml.ContextMenuStrip = this.contextMenuStrip1;
            this.treeViewXml.Location = new System.Drawing.Point(12, 12);
            this.treeViewXml.Name = "treeViewXml";
            this.treeViewXml.Size = new System.Drawing.Size(300, 426);
            this.treeViewXml.TabIndex = 0;
            // 
            // lblNodeName
            // 
            this.lblNodeName.AutoSize = true;
            this.lblNodeName.Location = new System.Drawing.Point(332, 57);
            this.lblNodeName.Name = "lblNodeName";
            this.lblNodeName.Size = new System.Drawing.Size(67, 13);
            this.lblNodeName.TabIndex = 1;
            this.lblNodeName.Text = "Node Name:";
            // 
            // lblNodeValue
            // 
            this.lblNodeValue.AutoSize = true;
            this.lblNodeValue.Location = new System.Drawing.Point(332, 93);
            this.lblNodeValue.Name = "lblNodeValue";
            this.lblNodeValue.Size = new System.Drawing.Size(66, 13);
            this.lblNodeValue.TabIndex = 2;
            this.lblNodeValue.Text = "Node Value:";
            // 
            // txtNodeName
            // 
            this.txtNodeName.Location = new System.Drawing.Point(405, 54);
            this.txtNodeName.Name = "txtNodeName";
            this.txtNodeName.Size = new System.Drawing.Size(250, 20);
            this.txtNodeName.TabIndex = 3;
            // 
            // txtNodeValue
            // 
            this.txtNodeValue.Location = new System.Drawing.Point(405, 90);
            this.txtNodeValue.Name = "txtNodeValue";
            this.txtNodeValue.Size = new System.Drawing.Size(250, 20);
            this.txtNodeValue.TabIndex = 4;
            // 
            // btnAddNode
            // 
            this.btnAddNode.Location = new System.Drawing.Point(332, 133);
            this.btnAddNode.Name = "btnAddNode";
            this.btnAddNode.Size = new System.Drawing.Size(135, 23);
            this.btnAddNode.TabIndex = 5;
            this.btnAddNode.Text = "Add Node";
            this.btnAddNode.UseVisualStyleBackColor = true;
            this.btnAddNode.Click += new System.EventHandler(this.btnAddNode_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(485, 133);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(135, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save XML";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // comboBox
            // 
            this.comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Location = new System.Drawing.Point(335, 12);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(220, 21);
            this.comboBox.TabIndex = 7;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dodajToolStripMenuItem,
            this.promijeniToolStripMenuItem,
            this.obrisiToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(126, 70);
            // 
            // dodajToolStripMenuItem
            // 
            this.dodajToolStripMenuItem.Name = "dodajToolStripMenuItem";
            this.dodajToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.dodajToolStripMenuItem.Text = "Dodaj";
            // 
            // promijeniToolStripMenuItem
            // 
            this.promijeniToolStripMenuItem.Name = "promijeniToolStripMenuItem";
            this.promijeniToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.promijeniToolStripMenuItem.Text = "Promijeni";
            // 
            // obrisiToolStripMenuItem
            // 
            this.obrisiToolStripMenuItem.Name = "obrisiToolStripMenuItem";
            this.obrisiToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.obrisiToolStripMenuItem.Text = "Obrisi";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.comboBox);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnAddNode);
            this.Controls.Add(this.txtNodeValue);
            this.Controls.Add(this.txtNodeName);
            this.Controls.Add(this.lblNodeValue);
            this.Controls.Add(this.lblNodeName);
            this.Controls.Add(this.treeViewXml);
            this.Name = "Form1";
            this.Text = "XML Editor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dodajToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem promijeniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obrisiToolStripMenuItem;
    }
}

