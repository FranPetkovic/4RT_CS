﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.Specialized;
using System.Diagnostics;

namespace Room_Management
{
    public class CKonekcija
    {
        private CKonekcija() {
            connStr = @"server=" + ConfigurationManager.AppSettings.Get("server")
               + ";uid=" + ConfigurationManager.AppSettings.Get("uid")
               + ";pwd=" + ConfigurationManager.AppSettings.Get("pwd")
               + ";database=" + ConfigurationManager.AppSettings.Get("database");
            Debug.WriteLine(connStr);
            myConnection = new SqlConnection(connStr);
        }
        private static String connStr;
        public SqlConnection myConnection { get; }

        private static CKonekcija instance = null;
        public static CKonekcija Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CKonekcija();
                }
                return instance;
            }
        }


    }
}
