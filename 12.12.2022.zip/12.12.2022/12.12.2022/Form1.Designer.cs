﻿namespace _12._12._2022
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox_Osoba = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_Automobil = new System.Windows.Forms.ComboBox();
            this.button_Posudi = new System.Windows.Forms.Button();
            this.dateTimePicker_posudba = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker_kraj = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.listBox_Posudeni = new System.Windows.Forms.ListBox();
            this.button_Osvijezi = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBox_Osoba
            // 
            this.comboBox_Osoba.FormattingEnabled = true;
            this.comboBox_Osoba.Location = new System.Drawing.Point(88, 33);
            this.comboBox_Osoba.Name = "comboBox_Osoba";
            this.comboBox_Osoba.Size = new System.Drawing.Size(121, 23);
            this.comboBox_Osoba.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Osoba:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(264, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Automobil:";
            // 
            // comboBox_Automobil
            // 
            this.comboBox_Automobil.FormattingEnabled = true;
            this.comboBox_Automobil.Location = new System.Drawing.Point(337, 33);
            this.comboBox_Automobil.Name = "comboBox_Automobil";
            this.comboBox_Automobil.Size = new System.Drawing.Size(121, 23);
            this.comboBox_Automobil.TabIndex = 3;
            // 
            // button_Posudi
            // 
            this.button_Posudi.Location = new System.Drawing.Point(713, 91);
            this.button_Posudi.Name = "button_Posudi";
            this.button_Posudi.Size = new System.Drawing.Size(75, 23);
            this.button_Posudi.TabIndex = 4;
            this.button_Posudi.Text = "Posudi";
            this.button_Posudi.UseVisualStyleBackColor = true;
            this.button_Posudi.Click += new System.EventHandler(this.button_Posudi_Click);
            // 
            // dateTimePicker_posudba
            // 
            this.dateTimePicker_posudba.Location = new System.Drawing.Point(597, 33);
            this.dateTimePicker_posudba.Name = "dateTimePicker_posudba";
            this.dateTimePicker_posudba.Size = new System.Drawing.Size(200, 23);
            this.dateTimePicker_posudba.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(496, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Datum posudbe:";
            // 
            // dateTimePicker_kraj
            // 
            this.dateTimePicker_kraj.Location = new System.Drawing.Point(597, 62);
            this.dateTimePicker_kraj.Name = "dateTimePicker_kraj";
            this.dateTimePicker_kraj.Size = new System.Drawing.Size(200, 23);
            this.dateTimePicker_kraj.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(468, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Datum kraja posudbe:";
            // 
            // listBox_Posudeni
            // 
            this.listBox_Posudeni.FormattingEnabled = true;
            this.listBox_Posudeni.ItemHeight = 15;
            this.listBox_Posudeni.Location = new System.Drawing.Point(31, 156);
            this.listBox_Posudeni.Name = "listBox_Posudeni";
            this.listBox_Posudeni.Size = new System.Drawing.Size(202, 229);
            this.listBox_Posudeni.TabIndex = 9;
            // 
            // button_Osvijezi
            // 
            this.button_Osvijezi.Location = new System.Drawing.Point(31, 391);
            this.button_Osvijezi.Name = "button_Osvijezi";
            this.button_Osvijezi.Size = new System.Drawing.Size(75, 23);
            this.button_Osvijezi.TabIndex = 10;
            this.button_Osvijezi.Text = "Osvijezi";
            this.button_Osvijezi.UseVisualStyleBackColor = true;
            this.button_Osvijezi.Click += new System.EventHandler(this.button_Osvijezi_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 15);
            this.label5.TabIndex = 11;
            this.label5.Text = "Zaduzena vozila:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button_Osvijezi);
            this.Controls.Add(this.listBox_Posudeni);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dateTimePicker_kraj);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateTimePicker_posudba);
            this.Controls.Add(this.button_Posudi);
            this.Controls.Add(this.comboBox_Automobil);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_Osoba);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox comboBox_Osoba;
        private Label label1;
        private Label label2;
        private ComboBox comboBox_Automobil;
        private Button button_Posudi;
        private DateTimePicker dateTimePicker_posudba;
        private Label label3;
        private DateTimePicker dateTimePicker_kraj;
        private Label label4;
        private ListBox listBox_Posudeni;
        private Button button_Osvijezi;
        private Label label5;
    }
}