using System.Data.SqlClient;

namespace _12._12._2022
{
    public partial class Form1 : Form
    {
        private string connStr = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=VozniPark;User ID=sa;Password=Radijator1";
        public Form1()
        {
            InitializeComponent();
        }

        public void initOsobe()
        {
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from Osoba", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while(reader.Read())
            {
                COsoba.dodajOsobu(int.Parse(reader["ID"].ToString()), reader["Ime"].ToString(), reader["Prezime"].ToString(), bool.Parse(reader["Posudio"].ToString()));
            }
            reader.Close();
            conn.Close();

            foreach(COsoba o in COsoba.vratiOsobe())
            {
                comboBox_Osoba.Items.Add(o);
            }
        }

        public void initAutomobil()
        {
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from Automobil", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                CAutomobil.dodajAutomobil(int.Parse(reader["ID"].ToString()),
                    reader["Naziv"].ToString(), reader["Registracija"].ToString(),
                    bool.Parse(reader["Posudeno"].ToString()), bool.Parse(reader["Rashodovano"].ToString()));
            }
            reader.Close();
            conn.Close();

            foreach (CAutomobil a in CAutomobil.vratiAutomobile())
            {
                comboBox_Automobil.Items.Add(a);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            initOsobe();
            initAutomobil();
        }

        private void button_Posudi_Click(object sender, EventArgs e)
        {
            if (comboBox_Osoba.SelectedItem == null || comboBox_Automobil.SelectedItem == null)
                return;
            if((comboBox_Osoba.SelectedItem as COsoba).vratiPosudio())
            {
                MessageBox.Show((comboBox_Osoba.SelectedItem as COsoba).ToString() + " je vec posudio auto");
                return;
            }
            if ((comboBox_Automobil.SelectedItem as CAutomobil).vratiPosudeno())
            {
                MessageBox.Show((comboBox_Automobil.SelectedItem as CAutomobil).ToString() + " je vec posuden");
                return;
            }

            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            string query = "insert into Posudbe(Osoba_ID, Automobil_ID, Datum_posudbe," +
                " Datum_kraja_posudbe, Zavrseno) values ('" +
                (comboBox_Osoba.SelectedItem as COsoba).vratiID() + "', '" +
                (comboBox_Automobil.SelectedItem as CAutomobil).vratiID() + "', '" +
                dateTimePicker_posudba.Value.ToString("yyyy-MM-dd") + "', '" +
                dateTimePicker_kraj.Value.ToString("yyyy-MM-dd") + "', 'False')";
                ;
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();

            query = "update Osoba set Posudio = 'True' where ID='" +
                (comboBox_Osoba.SelectedItem as COsoba).vratiID() + "'";
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            (comboBox_Osoba.SelectedItem as COsoba).posudiAuto();

            query = "update Automobil set Posudeno = 'True' where ID='" +
                (comboBox_Automobil.SelectedItem as CAutomobil).vratiID() + "'";
            cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            (comboBox_Automobil.SelectedItem as CAutomobil).posudeno();

            conn.Close();
        }

        private void button_Osvijezi_Click(object sender, EventArgs e)
        {
            listBox_Posudeni.Items.Clear();

            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select Osoba_ID, Automobil_ID, Ime, Prezime, Naziv from Posudbe " +
                "inner join Osoba on Osoba_ID = Osoba.ID inner join Automobil on Automobil_ID = Automobil.ID", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            
            while(reader.Read())
            {
                listBox_Posudeni.Items.Add(reader["Ime"].ToString() + " " + reader["Prezime"].ToString()
                    + " " + reader["Naziv"].ToString());
            }

            reader.Close();
            conn.Close();
        }
    }
}