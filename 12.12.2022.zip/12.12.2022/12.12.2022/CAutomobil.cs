﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace _12._12._2022
{
    internal class CAutomobil
    {
        private static List<CAutomobil> Automobili = new List<CAutomobil>();
        private int ID;
        private string Naziv, Registracija;
        private bool Posudeno, Rashodovano;

        private CAutomobil(int iD, string naziv, string registracija, bool posudeno, bool rashodovano)
        {
            ID = iD;
            Naziv = naziv;
            Registracija = registracija;
            Posudeno = posudeno;
            Rashodovano = rashodovano;
        }

        public static void dodajAutomobil(int iD, string naziv, string registracija, bool posudeno, bool rashodovano)
        {
            CAutomobil.Automobili.Add(new CAutomobil(iD, naziv, registracija, posudeno, rashodovano));
        }

        public static List<CAutomobil> vratiAutomobile()
        {
            return Automobili;
        }

        public void posudeno()
        {
            Posudeno = true;
        }

        public int vratiID()
        {
            return ID;
        }

        public bool vratiPosudeno()
        {
            return Posudeno;
        }

        public override string ToString()
        {
            return Registracija + " " + Naziv;
        }
    }
}
