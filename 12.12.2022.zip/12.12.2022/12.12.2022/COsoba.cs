﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._12._2022
{
    internal class COsoba
    {
        private static List<COsoba> Osobe = new List<COsoba>();
        private int ID;
        private string Ime, Prezime;
        private bool Posudio;

        private COsoba(int iD, string ime, string prezime, bool posudio)
        {
            ID = iD;
            Ime = ime;
            Prezime = prezime;
            Posudio = posudio;
        }

        public static void dodajOsobu(int iD, string ime, string prezime, bool posudio)
        {
            COsoba.Osobe.Add(new COsoba(iD, ime, prezime, posudio));
        }

        public static List<COsoba> vratiOsobe()
        {
            return Osobe;
        }

        public void posudiAuto()
        {
            Posudio = true;
        }

        public int vratiID()
        {
            return ID;
        }
        
        public bool vratiPosudio()
        {
            return Posudio;
        }

        public override string ToString()
        {
            return Ime + " " + Prezime;
        }
    }
}
