﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._12._2022
{
    internal class CPosudbe
    {
        private static List<CPosudbe> Posudbe = new List<CPosudbe>();
        private int ID, Osoba_ID, Automobil_ID;
        private DateTime Datum_posudbe, Datum_kraja_posudbe;
        private bool Zavrseno;

        private CPosudbe(int id, int osoba_ID, int automobil_ID, DateTime datum_posudbe, DateTime datum_kraja_posudbe, bool zavrseno)
        {
            ID = id;
            Osoba_ID = osoba_ID;
            Automobil_ID = automobil_ID;
            Datum_posudbe = datum_posudbe;
            Datum_kraja_posudbe = datum_kraja_posudbe;
            Zavrseno = zavrseno;
        }

        public static void dodajPosudbu(int id, int osoba_ID, int automobil_ID, DateTime datum_posudbe, DateTime datum_kraja_posudbe, bool zavrseno)
        {
            CPosudbe.Posudbe.Add(new CPosudbe(id, osoba_ID, automobil_ID, datum_posudbe, datum_kraja_posudbe, zavrseno));
        }

        public static List<CPosudbe> vratiPosudbe()
        {
            return Posudbe;
        }

    }
}
